#include "station_process.h"

namespace CS5310
{
   StationProcess::StationProcess() {;}

   StationProcess::wait_interval
   StationProcess::get_bebo_time (const size_t ith_collision) {;}

   StationProcess::station_status
   StationProcess::get_station_status(const int station_address) {;}

   StationProcess::data_frame*
   StationProcess::get_data_frame(const int station_address) x

   }
}
